# Cara membuat APK dari HP Android

1. Ekstrak ZIP proyek ini.
2. Buka https://github.com di browser dan masuk/buat akun.
3. Buat repository baru (Public atau Private).
4. Unggah semua isi folder proyek hasil ekstrak ke repository, termasuk folder `.github`.
   Jika folder tersembunyi tidak terlihat, aktifkan tampilan file tersembunyi atau unggah workflow secara terpisah.
5. Buka tab Actions pada repository, pilih workflow "Build Android APK", lalu tekan Run workflow.
6. Tunggu sampai proses selesai dengan status hijau.
7. Buka hasil run, unduh artifact bernama `Exambro-UI-Demo-debug`, lalu ekstrak ZIP artifact.
8. Instal `app-debug.apk` pada HP. Android mungkin meminta izin instalasi dari sumber tersebut.

Catatan:
- Ini APK debug untuk uji coba, bukan rilis Play Store.
- Tombol asisten yang ada masih demo UI dan belum terhubung ke ChatGPT sungguhan.
- Aplikasi ini hanya untuk latihan/belajar, bukan untuk mengakali pengawasan ujian.
