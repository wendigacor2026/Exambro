package com.example.exambrouidemo

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 14, 30)
    private val panel = Color.rgb(17, 27, 49)
    private val blue = Color.rgb(49, 156, 255)
    private val muted = Color.rgb(157, 176, 204)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildScreen()
    }

    private fun rounded(color: Int, radius: Float, stroke: Int = Color.TRANSPARENT): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (stroke != Color.TRANSPARENT) setStroke(1, stroke)
        }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }
    }


    private fun showStudyAssistant() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 12, 22, 8)
        }
        box.addView(label("Asisten Belajar", 20f, Color.WHITE, true))
        val note = label(
            "Tombol ini adalah contoh tampilan chat. Untuk jawaban ChatGPT sungguhan, aplikasi perlu dihubungkan ke layanan AI melalui backend yang aman.",
            14f, muted
        )
        note.setPadding(0, 12, 0, 12)
        box.addView(note)
        val question = EditText(this).apply {
            hint = "Tulis pertanyaan latihan..."
            setTextColor(Color.WHITE)
            setHintTextColor(muted)
            setPadding(12, 10, 12, 10)
            background = rounded(Color.rgb(10, 19, 36), 12f)
        }
        box.addView(question)
        val dialog = android.app.AlertDialog.Builder(this)
            .setView(box)
            .setNegativeButton("Tutup", null)
            .setPositiveButton("Kirim", null)
            .create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(rounded(panel, 20f))
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                Toast.makeText(this, "Demo saja: chat AI belum dihubungkan.", Toast.LENGTH_LONG).show()
            }
        }
        dialog.show()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 26, 24, 28)
        }
        scroll.addView(root)

        // Floating study-assistant button, visible only inside this demo app.
        val frame = android.widget.FrameLayout(this)
        frame.addView(scroll, android.widget.FrameLayout.LayoutParams(-1, -1))
        val fab = TextView(this).apply {
            text = "✦"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(blue, 100f)
            elevation = 12f
            contentDescription = "Buka asisten belajar"
            setOnClickListener { showStudyAssistant() }
        }
        val fabParams = android.widget.FrameLayout.LayoutParams(60, 60, Gravity.BOTTOM or Gravity.END)
        fabParams.setMargins(0, 0, 22, 24)
        frame.addView(fab, fabParams)
        setContentView(frame)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "E"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            background = rounded(blue, 18f)
        }
        top.addView(logo, LinearLayout.LayoutParams(52, 52))
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 0, 0, 0)
        }
        brand.addView(label("EXAMBRO", 20f, Color.WHITE, true))
        brand.addView(label("UI DEMO • UNOFFICIAL", 10f, muted, true))
        top.addView(brand)
        val settings = TextView(this).apply {
            text = "⚙"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        top.addView(settings, LinearLayout.LayoutParams(0, 52, 1f).apply { gravity = Gravity.END })
        root.addView(top)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 24)
            background = rounded(Color.rgb(18, 48, 86), 24f, Color.rgb(39, 112, 190))
        }
        val heroTitle = label("Ujian jadi lebih fokus.", 25f, Color.WHITE, true)
        hero.addView(heroTitle)
        val subtitle = label("Masuk ke ruang ujian demo dengan tampilan yang simpel dan modern.", 14f, Color.rgb(210, 228, 250))
        subtitle.setPadding(0, 10, 0, 0)
        hero.addView(subtitle)
        val pill = TextView(this).apply {
            text = "  ●  SISTEM DEMO  "
            textSize = 11f
            setTextColor(Color.WHITE)
            setPadding(10, 8, 10, 8)
            background = rounded(Color.rgb(35, 105, 174), 30f)
        }
        val pp = LinearLayout.LayoutParams(-2, -2).apply { topMargin = 18 }
        hero.addView(pill, pp)
        val hp = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 28 }
        root.addView(hero, hp)

        val section = label("Masuk Ujian", 20f, Color.WHITE, true)
        val sp = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 28; bottomMargin = 14 }
        root.addView(section, sp)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            background = rounded(panel, 20f, Color.rgb(38, 54, 82))
        }
        card.addView(label("Nama siswa", 13f, muted, true))
        val name = EditText(this).apply {
            hint = "Masukkan nama"
            textSize = 15f
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(105, 125, 153))
            background = rounded(Color.rgb(10, 19, 36), 12f)
            setPadding(14, 12, 14, 12)
        }
        card.addView(name, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 8; bottomMargin = 16 })
        card.addView(label("Kode ujian", 13f, muted, true))
        val code = EditText(this).apply {
            hint = "Contoh: DEMO-2026"
            textSize = 15f
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(105, 125, 153))
            background = rounded(Color.rgb(10, 19, 36), 12f)
            setPadding(14, 12, 14, 12)
        }
        card.addView(code, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 8; bottomMargin = 18 })

        val start = Button(this).apply {
            text = "MULAI UJIAN DEMO  →"
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(blue, 14f)
            setOnClickListener {
                val student = name.text.toString().trim()
                val exam = code.text.toString().trim()
                val message = if (student.isEmpty() || exam.isEmpty()) {
                    "Isi nama dan kode ujian terlebih dahulu."
                } else {
                    "Halo, $student! Ini hanya tampilan demo; belum terhubung ke ujian."
                }
                Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
            }
        }
        card.addView(start, LinearLayout.LayoutParams(-1, 52))
        root.addView(card)

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(2, 20, 2, 0)
        }
        info.addView(label("ⓘ  Aplikasi contoh antarmuka", 12f, muted))
        root.addView(info)

        val footer = label("Versi 1.0  •  Tidak terafiliasi dengan aplikasi Exambro resmi", 10f, Color.rgb(105, 125, 153))
        footer.gravity = Gravity.CENTER
        val fp = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 28 }
        root.addView(footer, fp)
    }
}
